# Analyse des dépendances – Analyse ace3i-connector-sydonia-simulators

- Fichier : `pom.xml`
- Décision globale : **Bloquée**
- Autorisées : 4 · À valider : 3 · Bloquées : 3 · Incomplètes : 0
- Politique ACE3i : 2026.10-2 · analyse du 2026-11-02T09:49:27.703193Z


## Plan d'action

1. **Mettre à jour postgresql de 42.5.1 à 42.7.14** (Bloquée, 2 vulnérabilité(s))  
   Changer la version de la dépendance dans le pom.xml.  
   `org.postgresql:postgresql:42.5.1`
2. **Mettre à jour spring-boot-starter-web de 2.2.7.RELEASE à 2.5.12** (Bloquée, 1 vulnérabilité(s))  
   Changer la version de la dépendance dans le pom.xml.  
   `org.springframework.boot:spring-boot-starter-web:2.2.7.RELEASE`
3. **Aucune version sûre pour wsdl4j** (Bloquée)  
   Retirer la dépendance, attendre un correctif, ou faire neutraliser les CVE non exploitables (DEP-07, justifiée et datée).  
   `wsdl4j:wsdl4j:1.6.3`
4. **Mettre à jour commons-lang3 de 3.9 à 3.18.0** (À valider, 1 vulnérabilité(s))  
   Changer la version de la dépendance dans le pom.xml.  
   `org.apache.commons:commons-lang3:3.9`
5. **Aucune version sûre pour lombok** (À valider)  
   Retirer la dépendance, attendre un correctif, ou faire neutraliser les CVE non exploitables (DEP-07, justifiée et datée).  
   `org.projectlombok:lombok:1.18.32`
6. **Aucune version sûre pour spring-boot-starter-thymeleaf** (À valider)  
   Retirer la dépendance, attendre un correctif, ou faire neutraliser les CVE non exploitables (DEP-07, justifiée et datée).  
   `org.springframework.boot:spring-boot-starter-thymeleaf:2.4.9`

## Détail par dépendance

| Dépendance | Version | Décision | CVE | Licence | Proposition |
|---|---|---|---|---|---|
| `org.postgresql:postgresql` | 42.5.1 | Bloquée | CVE-2024-1597 CVE-2026-42198 | BSD-2-Clause | 42.7.14 |
| `wsdl4j:wsdl4j` | 1.6.3 | Bloquée | — | CPL | — |
| `org.springframework.boot:spring-boot-starter-web` | 2.2.7.RELEASE | Bloquée | CVE-2022-22965 | Apache-2.0 | 2.5.12 |
| `org.apache.commons:commons-lang3` | 3.9 | À valider | CVE-2025-48924 | Apache-2.0 | 3.18.0 |
| `org.projectlombok:lombok` | 1.18.32 | À valider | — | MIT | — |
| `org.springframework.boot:spring-boot-starter-thymeleaf` | 2.4.9 | À valider | — | Apache-2.0 | — |

5 dépendance(s) autorisée(s) non listée(s).
